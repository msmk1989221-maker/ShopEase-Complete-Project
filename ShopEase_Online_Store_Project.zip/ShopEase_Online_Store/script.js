const products = [
  {id:1,name:"Everyday Ceramic Mug",category:"Home",price:349,badge:"BESTSELLER",image:"https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=700&q=80"},
  {id:2,name:"Soft Knit Tote",category:"Accessories",price:599,badge:"POPULAR",image:"https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=700&q=80"},
  {id:3,name:"Minimal Desk Lamp",category:"Home",price:1299,badge:"NEW",image:"https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=700&q=80"},
  {id:4,name:"Wireless Headphones",category:"Tech",price:1899,badge:"FAVOURITE",image:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=700&q=80"},
  {id:5,name:"Classic Wrist Watch",category:"Accessories",price:999,badge:"TIMELESS",image:"https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=700&q=80"},
  {id:6,name:"Reusable Water Bottle",category:"Home",price:449,badge:"EVERYDAY",image:"https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=700&q=80"},
  {id:7,name:"Compact Bluetooth Speaker",category:"Tech",price:1499,badge:"NEW",image:"https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=700&q=80"},
  {id:8,name:"Sunglasses Classic",category:"Accessories",price:699,badge:"SUMMER PICK",image:"https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=700&q=80"}
];
let activeCategory = "All";
let cart = JSON.parse(localStorage.getItem("shopeaseCart") || "[]");
const productGrid = document.getElementById("productGrid");
const searchInput = document.getElementById("searchInput");
const sortSelect = document.getElementById("sortSelect");

function rupees(amount){return "₹" + amount.toLocaleString("en-IN");}
function saveCart(){localStorage.setItem("shopeaseCart",JSON.stringify(cart));}
function renderProducts(){
  const term = searchInput.value.trim().toLowerCase();
  let list = products.filter(p =>
    (activeCategory === "All" || p.category === activeCategory) &&
    (p.name.toLowerCase().includes(term) || p.category.toLowerCase().includes(term))
  );
  if(sortSelect.value === "low") list.sort((a,b)=>a.price-b.price);
  if(sortSelect.value === "high") list.sort((a,b)=>b.price-a.price);
  productGrid.innerHTML = "";
  document.getElementById("emptyState").hidden = list.length > 0;
  list.forEach(p=>{
    const card=document.createElement("article");card.className="product-card";
    const wrap=document.createElement("div");wrap.className="product-image-wrap";
    const img=document.createElement("img");img.className="product-image";img.src=p.image;img.alt=p.name;img.loading="lazy";
    img.onerror=()=>{img.style.display="none";wrap.style.background="#e8eee4";wrap.innerHTML='<span style="display:grid;place-items:center;height:100%;font-size:3rem">🛍️</span>';};
    const badge=document.createElement("span");badge.className="product-badge";badge.textContent=p.badge;wrap.append(img,badge);
    const content=document.createElement("div");content.className="product-content";
    const category=document.createElement("p");category.className="product-category";category.textContent=p.category;
    const name=document.createElement("h3");name.className="product-name";name.textContent=p.name;
    const bottom=document.createElement("div");bottom.className="product-bottom";
    const price=document.createElement("span");price.className="price";price.textContent=rupees(p.price);
    const add=document.createElement("button");add.className="add-button";add.textContent="+";add.setAttribute("aria-label","Add "+p.name+" to bag");
    add.addEventListener("click",()=>addToCart(p.id));bottom.append(price,add);content.append(category,name,bottom);card.append(wrap,content);productGrid.append(card);
  });
}
function addToCart(id){const item=cart.find(i=>i.id===id);if(item)item.quantity++;else cart.push({id,quantity:1});saveCart();renderCart();const btn=document.getElementById("cartButton");btn.animate([{transform:"scale(1)"},{transform:"scale(1.08)"},{transform:"scale(1)"}],{duration:250});}
function removeFromCart(id){cart=cart.filter(i=>i.id!==id);saveCart();renderCart();}
function renderCart(){
  const count=cart.reduce((sum,item)=>sum+item.quantity,0);document.getElementById("cartCount").textContent=count;
  const list=document.getElementById("cartItems");list.innerHTML="";
  if(!cart.length){list.innerHTML='<p class="muted">Your bag is empty. Add something you love.</p>';}
  cart.forEach(item=>{
    const p=products.find(product=>product.id===item.id);if(!p)return;
    const row=document.createElement("div");row.className="cart-row";
    const img=document.createElement("img");img.src=p.image;img.alt="";
    const info=document.createElement("div");const name=document.createElement("strong");name.textContent=p.name;const quantity=document.createElement("small");quantity.textContent=`Qty: ${item.quantity} · ${rupees(p.price)} each`;info.append(name,quantity);
    const remove=document.createElement("button");remove.className="remove-item";remove.textContent="Remove";remove.addEventListener("click",()=>removeFromCart(item.id));row.append(img,info,remove);list.append(row);
  });
  const total=cart.reduce((sum,item)=>{const p=products.find(product=>product.id===item.id);return sum+(p?p.price*item.quantity:0);},0);
  document.getElementById("cartTotal").textContent=rupees(total);
  document.getElementById("checkoutButton").disabled=cart.length===0;
}
document.querySelectorAll("[data-filter]").forEach(button=>button.addEventListener("click",()=>{
  activeCategory=button.dataset.filter;
  document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b===button));
  renderProducts();
}));
document.querySelectorAll(".category-strip a").forEach(link=>link.addEventListener("click",()=>{
  activeCategory=link.dataset.category;
  document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b.dataset.filter===activeCategory));
  renderProducts();
}));
searchInput.addEventListener("input",renderProducts);sortSelect.addEventListener("change",renderProducts);
const cartDialog=document.getElementById("cartDialog");
document.getElementById("cartButton").addEventListener("click",()=>{renderCart();cartDialog.showModal();});
document.getElementById("closeCart").addEventListener("click",()=>cartDialog.close());
cartDialog.addEventListener("click",e=>{if(e.target===cartDialog)cartDialog.close();});
document.getElementById("checkoutButton").addEventListener("click",()=>{
  document.getElementById("checkoutFeedback").textContent="This is a demo store. No payment has been taken.";
});
document.getElementById("newsletterForm").addEventListener("submit",e=>{
  e.preventDefault();const email=document.getElementById("newsletterEmail").value.trim();
  const subscribers=JSON.parse(localStorage.getItem("shopeaseSubscribers")||"[]");
  if(!subscribers.includes(email))subscribers.push(email);
  localStorage.setItem("shopeaseSubscribers",JSON.stringify(subscribers));
  document.getElementById("newsletterFeedback").textContent="Thanks for joining! Your email is saved in this browser demo.";
  e.currentTarget.reset();
});
document.getElementById("contactForm").addEventListener("submit",e=>{
  e.preventDefault();const data=Object.fromEntries(new FormData(e.currentTarget).entries());
  const messages=JSON.parse(localStorage.getItem("shopeaseMessages")||"[]");messages.push({...data,submittedAt:new Date().toISOString()});
  localStorage.setItem("shopeaseMessages",JSON.stringify(messages));
  document.getElementById("contactFeedback").textContent="Thanks! Your message has been saved in this browser demo.";e.currentTarget.reset();
});
const menuToggle=document.getElementById("menuToggle"),nav=document.getElementById("nav");
menuToggle.addEventListener("click",()=>nav.classList.toggle("open"));
nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));
renderProducts();renderCart();
