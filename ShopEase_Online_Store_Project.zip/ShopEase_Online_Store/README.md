# ShopEase — Online Store Website

A responsive frontend e-commerce demo built with HTML, CSS, and JavaScript, inspired by beginner HTML/CSS course concepts.

## Files
- `index.html`: page layout and forms
- `style.css`: responsive styles and layouts
- `script.js`: product rendering, search, category filters, sorting, cart, and demo form storage

## Run locally
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Open `index.html` using Live Server, or double-click it in a browser.
4. Internet is required for remote product photos and Google Fonts.

## Features
- Responsive navigation
- Product cards and category filters
- Search products by name/category
- Sort products by price
- Add and remove items from shopping bag
- Cart quantity and total calculation
- localStorage saves cart, newsletter demo entries, and contact messages

## Important
This is an educational frontend demo. Checkout does not process payments, and forms do not send emails or connect to a backend/database. Product details and images are placeholders.
